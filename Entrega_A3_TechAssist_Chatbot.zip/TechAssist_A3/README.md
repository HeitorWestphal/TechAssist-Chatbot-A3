# TechAssist AI — Chatbot Inteligente de Suporte e Helpdesk de TI (Nível 1)

> **Projeto Integrador A3 — Inteligência Artificial (40 Pontos)**  
> **Tema:** Central de Triagem e Suporte Técnico Corporativo com PLN Próprio e Classificação Supervisionada  
> **Equipe:** TechAssist AI Solutions  
> **Integrantes:** Heitor Westphal (e equipe)  

---

## 📌 1. Visão Geral do Projeto

O **TechAssist AI** é um agente conversacional inteligente projetado para solucionar um gargalo crítico em organizações modernas: a sobrecarga das equipes de suporte de TI decorrente de chamados repetitivos de Nível 1 (N1), como redefinição de senhas, falhas na VPN, lentidão na máquina e instalação de softwares homologados.

O sistema foi desenvolvido em estrita conformidade com os requisitos da **Avaliação A3 de IA**, implementando um **mecanismo autoral de Processamento de Linguagem Natural (PLN) e Aprendizado de Máquina**, sem dependência de chamadas opacas a APIs comerciais de LLMs.

---

## 🚀 2. Destaques dos Requisitos Técnicos

* **R1 — Conversação e Interface Multicanal:** Disponível em **Interface Gráfica Web** moderna e responsiva (Flask + TailwindCSS) e via **Terminal Interativo (CLI)** com modo de diagnóstico.
* **R2 — Domínio e Base de Conhecimento:** 8 categorias modeladas com base de autoatendimento curada (`data/knowledge_base.json`).
* **R3 — IA Implementada (Mecanismo Próprio):** Vetorização **TF-IDF com n-grams (1, 2)** combinada com classificador supervisionado de **Regressão Logística** e cálculo paralelo de **Similaridade por Cosseno**.
* **R4 — Fluxo Completo e Fallback Determinístico:** Pipeline `Entrada -> Pré-Processamento -> TF-IDF -> Inferência IA -> Confiança Híbrida -> Decisão -> Resposta`. Conta com limiar operacional de segurança (`threshold = 0.38`), evitando alucinações e oferecendo abertura de chamado N2 com protocolo (`#TK-XXXXX`).
* **R5 — Conjunto Formal de Validação:** 25 casos de teste estruturados cobrindo perguntas típicas, reformulações, gírias, ambiguidades e fora de escopo (`data/test_dataset.csv`).
* **R6 — Métricas e Matriz de Confusão:** Avaliação automatizada (`src/evaluate.py`), acurácia global de 72%, precisão de 100% nas intenções técnicas e análise crítica detalhada de falhas.
* **R7 — Autoria e Execução Simples:** 100% executável localmente, com código modular e sem necessidade de tokens pagos.

---

## 🛠️ 3. Instalação e Execução

### Pré-requisitos
* Python 3.10, 3.11 ou 3.12 instalado.
* Terminal macOS, Linux ou Windows (PowerShell/WSL).

### Passo 1: Clonar/Acessar o Diretório do Projeto
```bash
cd /Users/heitorwestphal/Downloads/A3Quarta
```

### Passo 2: Criar e Ativar o Ambiente Virtual (venv)
```bash
python3 -m venv venv
source venv/bin/activate
```
*(No Windows: `venv\Scripts\activate`)*

### Passo 3: Instalar as Dependências
```bash
pip install -r requirements.txt
```

---

## 💻 4. Como Executar

### 🌐 Opção A: Interface Web Interativa (Recomendada para Apresentação)
Inicie o servidor Flask:
```bash
python -m src.app_web
```
Abra o navegador no endereço: **`http://localhost:5000`**

**Recursos da Interface Web:**
* Design corporativo limpo estilo Service Desk moderno.
* Badges em tempo real indicando a **Intenção Detectada** e o **Score de Confiança da IA**.
* Botões de atalho rápido com as dúvidas mais frequentes.
* Modal explicativo sobre o mecanismo de PLN (Requisito R3).
* Botão de reiniciar sessão e histórico.

---

### 🖥️ Opção B: Interface via Linha de Comando (CLI)
Para homologação rápida no terminal:
```bash
python -m src.cli
```
* **Dica para a defesa:** Digite `debug: <frase>` no terminal para inspecionar os termos TF-IDF e pesos vetoriais em tempo real!

---

### 📊 Opção C: Executar a Suite de Avaliação e Métricas (R5 e R6)
Para rodar a bateria formal de 25 testes e recalcular as métricas:
```bash
python -m src.evaluate
```
Os resultados detalhados serão salvos em:
* `results/test_execution_results.csv`
* `results/metrics_summary.json`

---

## 🧠 5. Arquitetura da Inteligência Artificial

```
               [ Mensagem do Usuário ]
                          │
                          ▼
             [ src/nlp_preprocessor.py ]
          (Minúsculas, NFKD, Regex, Stopwords)
                          │
                          ▼
             [ src/intent_classifier.py ]
               Matriz TF-IDF (1, 2 n-grams)
                          │
             ┌────────────┴────────────┐
             ▼                         ▼
   Regressão Logística       Similaridade de Cosseno
   P(intenção | x)             com centróides
             └────────────┬────────────┘
                          ▼
              Score Híbrido de Confiança
           (0.65 × P_modelo + 0.35 × Cosseno)
                          │
             ┌────────────┴────────────┐
             ▼                         ▼
    Confiança >= 0.38          Confiança < 0.38 ou OOV
  [ Resposta da Base ]         [ Fallback Seguro ]
  (Procedimento Passo a Passo) (Oferta tópicos + Chamado N2)
```

### Onde está a IA no código?
* **Vetorização e Classificador:** [`src/intent_classifier.py`](file:///Users/heitorwestphal/Downloads/A3Quarta/src/intent_classifier.py)
* **Higienização e Normalização PLN:** [`src/nlp_preprocessor.py`](file:///Users/heitorwestphal/Downloads/A3Quarta/src/nlp_preprocessor.py)
* **Motor Conversacional e Decisão:** [`src/bot_engine.py`](file:///Users/heitorwestphal/Downloads/A3Quarta/src/bot_engine.py)

---

## 🎯 6. Roteiro para a Defesa ao Vivo (Perguntas da Banca)

Durante a apresentação de 8 minutos, o professor fará perguntas técnicas e proporá um teste surpresa:

1. **"Onde está a IA e como a decisão é tomada?"**
   * *Resposta:* "Está em `src/intent_classifier.py`. A entrada passa por normalização NFKD e remoção de ruídos em `src/nlp_preprocessor.py`. Em seguida, extraímos unigramas e bigramas ponderados por TF-IDF. A classificação combina a probabilidade do modelo logístico com a similaridade de cosseno. Se a confiança calculada superar 0.38, entregamos a resposta técnica; caso contrário, o fallback seguro é acionado."

2. **"O que acontece em caso de falha ou ambiguidade?"**
   * *Resposta:* "O sistema adota abstenção segura (não alucina). Diante de confiança abaixo de 38% ou termos desconhecidos, ele informa que a dúvida excede o Nível 1, lista os 5 temas suportados e oferece abertura direta de ticket para o Nível 2 humano, gerando o número de protocolo."

3. **"Se o professor fizer uma pergunta inédita ao vivo (ex: 'meu cabo de rede arrebentou'):"**
   * Se o bot reconhecer como problema de infraestrutura/hardware, acionará abertura de chamado.
   * Se a confiança for baixa, o bot acionará o fallback explicando perfeitamente por que a frase não atinge a certeza operacional necessária.

---

## 📁 7. Estrutura de Arquivos Entregues

```
A3Quarta/
├── data/
│   ├── knowledge_base.json        # Base de conhecimento de suporte técnico
│   ├── training_dataset.csv       # Dataset com 100+ exemplos de treino rotulados
│   └── test_dataset.csv           # 25 casos formais de validação (R5)
├── src/
│   ├── nlp_preprocessor.py        # Módulo de normalização textual e stopwords
│   ├── intent_classifier.py       # Modelo TF-IDF + Regressão Logística + Cosseno
│   ├── bot_engine.py              # Motor conversacional e controle de chamados
│   ├── app_web.py                 # Interface Web Flask
│   ├── cli.py                     # Interface de Linha de Comando
│   ├── evaluate.py                # Script de validação e métricas
│   └── templates/
│       └── index.html             # Interface Web responsiva (TailwindCSS)
├── results/
│   ├── test_execution_results.csv # Tabela com a execução dos 25 testes
│   └── metrics_summary.json       # Métricas consolidadas e matriz de confusão
├── docs/
│   ├── RELATORIO_TECNICO_A3.docx  # Relatório completo (>8 páginas formatadas)
│   └── RELATORIO_TECNICO_A3.md    # Versão em Markdown do relatório
├── Atividade_Checkpoint_Preenchida.docx # Checkpoint oficial preenchido
├── requirements.txt               # Dependências Python
└── README.md                      # Este manual completo
```
